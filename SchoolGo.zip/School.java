package school;

import java.util.ArrayList;

public class School {
	
	//arrayLists to store pupils and instructors
	ArrayList<Student> pupils;
	ArrayList<Teacher> instructors;
	
	//set pupils and instructors to students and teachers
	School(ArrayList<Student> students, ArrayList<Teacher> teachers){
		pupils = students;
		instructors = teachers;		
	}
	
	//return all within grade level
	public String getGradeLevel(int level){
		
		//start with empty string
		String year = "";
		
		//loop through arrayList
		for(int i = 0; i < pupils.size(); i++) {
			if(pupils.get(i).getLevel()  == level){
				year += pupils.get(i) + "\n";
			}
		}
		return year;
		
	}
	
	//format into string
	public String toString(){
		
		//start with empty string
		String everyone = "";
		
		//concatenate faculty by looping through instructors
		everyone += "Faculty:";
		for(int i = 0; i < instructors.size(); i++) {
			everyone += "\n" + instructors.get(i);
		}
		
		//concatenate student body by looping through pupils
		everyone += "\n\nStudent Body:";
		for(int i = 0; i < pupils.size(); i++){
			everyone += "\n" + pupils.get(i);
		}
		return everyone;
	}
}
