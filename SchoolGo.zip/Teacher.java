package school;

public class Teacher extends Person {
	
	//variable to be set
	private String course;
	
	//get variables with super and subject
	public Teacher(String fName, String lName, String subject){
		super(fName, lName);	
		course = subject;
	}
	
	//format with subject added
	public String toString() {
		return(super.toString() + "\n   Subject: " + course);
	}
}
