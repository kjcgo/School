package school;

public class Person{
	
	//variables
	private String firstName;
	private String lastName;
	
	//sets firstName and lastName
	public Person(String fname, String lname){
		firstName = fname;
		lastName = lname;
	}
	
	//returns formatted full name
	public String toString(){
		return(lastName + ", " + firstName);
	}
}
