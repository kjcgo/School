package school;

public class Student extends Person {
	
	//variables for student's id and grade
	private static int studentId = 0;
	int numStudent;
	int level;
	
	//constructor
	public Student(String fName, String lName, int gLevel){
	
		//Set fName and lName using super
		super(fName, lName);
		
		//Set grade level
		if(gLevel > 12 || gLevel < 0){
			level = 0; 
		}
		else{
			level = gLevel;
		}
		
		//increase and store studentId
		studentId++;
		numStudent = studentId;
		
		
	}

	//return the level
	public int getLevel() {
		return level;
	}
	
	//format string with id and grade
	public String toString() {
		return(super.toString() + "\n   Grade Level: " + level + "\n   ID #: " + numStudent);
	
	}
}
