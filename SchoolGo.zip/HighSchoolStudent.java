package school;

public class HighSchoolStudent extends Student {
	
	//variable 
	private double gradePointAvg;
	
	//constructor
	public HighSchoolStudent(String fName, String lName, int gLevel, double gpa){
		
		//super used to set variables
		super(fName, lName, gLevel);
		
		//set gradePointAvg
		if(gpa > 5 || gpa < 0) {
			gradePointAvg = 0;
		}
		else {
			gradePointAvg = gpa;
		}
	}
	
	//Return string with GPA attached
	public String toString() {
		return(super.toString() + "\n   GPA: " + gradePointAvg);
	}

}
